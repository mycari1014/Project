const test = require('node:test');
const assert = require('node:assert/strict');
const { slugify } = require('../src/slugify');

test('converts a simple phrase', () => {
  assert.equal(slugify('Hello World'), 'hello-world');
});

test('strips punctuation and collapses separators', () => {
  assert.equal(slugify('  Hello,   World!!  '), 'hello-world');
});

test('removes accents', () => {
  assert.equal(slugify('Café Münster'), 'cafe-munster');
});

test('returns empty string for symbols only', () => {
  assert.equal(slugify('!!!'), '');
});

test('throws on non-string input', () => {
  assert.throws(() => slugify(null), TypeError);
});
