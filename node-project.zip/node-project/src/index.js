const http = require('node:http');
const { slugify } = require('./slugify');

const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (url.pathname === '/slugify') {
    const text = url.searchParams.get('text') || '';
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ text, slug: slugify(text) }));
  }

  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Slugify service is running. Try /slugify?text=Hello World\n');
});

server.listen(PORT, () => console.log(`Listening on port ${PORT}`));
